systemctl команда (что делаем) объект (над чем делаем) 
ПРИМЕР - systemctl status sshd

systemctl disable/enable sshd - отключение службы (даже при рестарте изменения сохранятся)
systemctl list-units --all   : список всех юнитов(служб?)
systemctl lis-unit-file  вывод всех установленных в системе служб